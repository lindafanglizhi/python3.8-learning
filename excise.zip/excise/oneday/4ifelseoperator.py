print("请输入第一个数字：")
a = input()
num1 = int(a)
print("请输入第二个数字：")
b = input()
num2 = int(b)
if num1 > num2:
    print("第一个数字大于 第二个数字")
else:
    print("第一个数字不大于 第二个数字")
