from threeday.findindex import *
import sys


courses = ['python','java','black test','selenium']
index =find_index(courses,'java')
print(index,test)

