from distutils.core import setup


setup(
    # 是你将来要调用的函数名，不能超过10个字
    name='wrapperfor',
    version='0.0.1',
    # 是你函数所在的文件名
    py_modules=['wrapperforlist'],
    author='linda',
    author_email='lindafanglizhi@163.com',
    url='',
    description='a simple printer of nested lists'
)
