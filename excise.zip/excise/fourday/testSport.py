from fourday.firstclass2 import SportManList

jame = SportManList()
jame.a_name('linda')
print(jame)