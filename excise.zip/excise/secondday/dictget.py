ages = {
    'linda': 18,
    'leimeng': 51,
    'yujian': 31
}

# 从字典中获得key的值 ，如果有输出，如果没有写unknown

age = ages.get('linda1', 'Unknown')
print(age)


