from secondday import wrapperfor

books = ["lanuage", ["python", "java"], "life", ["tom ", "sophoie"]]

wrapperfor.print_lol(books)

