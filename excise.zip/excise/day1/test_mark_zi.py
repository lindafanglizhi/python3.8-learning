import pytest


@pytest.mark.webtest
def test_send_http():
    pass


@pytest.mark.apptest
def test_devide():
    pass


@pytest.mark.android
def test_search():
    pass


@pytest.mark.ios
def test_add():
    pass


def test_plus():
    pass


if __name__ == '__main__':
    pytest.main()
